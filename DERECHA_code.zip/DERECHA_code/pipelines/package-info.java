/**
 * The running pipelines
 */
/**
 * @author sallam.abualhaija <sallam.abualhaija@uni.lu>
 *
 */
package lu.svv.saa.linklaters.dpa.pipelines;
